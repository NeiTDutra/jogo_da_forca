# Jogo da forca

## Um simples jogo em html, css e javascript

Insere uma palavra e tem até sete chances para acertar antes que o boneco fique preso na forca.

### Teste de uso

Teste o [jogo da forca neste link](https://neitdutra.github.io/jogo_da_forca/)

### Escopo

Digite uma palavra, em seguida, digite trễs dicas relacionadas à palavra secreta.

(Novo) Opção para deixar o sistema escolher a palavra e as dicas.

Uma nova caixa de texto para digitar a letra.

A letra é testada pelo script e, caso exista na palavra, aparece na caixa/posição.

Se não existir, uma parte do boneco aparece no espaço da forca.

A cada dois erros uma dica aparece na mesma ordem que foi digitada.

No sétimo erro o boneco é enforcado.

### Tecnologia

(em desenvolvimento)

*Projetando a refatoração do código com algun(s) framework(s)...*


